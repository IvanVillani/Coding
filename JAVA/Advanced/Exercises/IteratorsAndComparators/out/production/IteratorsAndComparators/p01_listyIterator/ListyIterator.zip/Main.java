package p01_listyIterator;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

import static java.lang.System.in;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));

        String input = reader.readLine();
        ListyIterator<String> listyIterator = null;

        while (!"END".equals(input)) {
            String[] arr = input.split(" ");

            switch (arr[0]) {
                case "Create":
                    if (arr.length > 1) {
                        listyIterator = new ListyIterator<>(Arrays.stream(arr).skip(1).toArray(String[]::new));
                    }else {
                        listyIterator = new ListyIterator<>();
                    }
                    break;
                case "Move":
                    if (listyIterator != null) {
                        System.out.println(listyIterator.move());
                    }
                    break;
                case "HasNext":
                    if (listyIterator != null) {
                        System.out.println(listyIterator.hasNext());
                    }
                    break;
                case "Print":
                    if (listyIterator != null) {
                        listyIterator.print();
                    }
                    break;
            }

            input = reader.readLine();
        }
        reader.close();
    }
}
