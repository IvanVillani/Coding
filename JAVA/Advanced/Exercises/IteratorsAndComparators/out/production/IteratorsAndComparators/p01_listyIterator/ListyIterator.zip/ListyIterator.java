package p01_listyIterator;

import java.util.Arrays;
import java.util.List;

public class ListyIterator<T> {
    private List<T> elements;
    private int index;

    @SuppressWarnings("unchecked")
    public ListyIterator(T... elements) {
        this.elements = Arrays.asList(elements);
    }

    public boolean move() {
        if (this.hasNext()) {
            this.index++;
            return true;
        }
        return false;
    }

    public boolean hasNext() {
        return this.index < this.elements.size() - 1;
    }

    public void print() {
        if (this.elements.size() > 0) {
            System.out.println(this.elements.get(this.index));
        }else {
            System.out.println("Invalid Operation!");
        }
    }
}
