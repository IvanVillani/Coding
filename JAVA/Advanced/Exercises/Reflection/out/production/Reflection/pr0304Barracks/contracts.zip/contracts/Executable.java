package pr0304Barracks.contracts;

public interface Executable {

	String execute();

}
