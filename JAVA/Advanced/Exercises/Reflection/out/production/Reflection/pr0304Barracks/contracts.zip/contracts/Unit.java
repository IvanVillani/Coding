package pr0304Barracks.contracts;

public interface Unit extends Destroyable, Attacker {
}
