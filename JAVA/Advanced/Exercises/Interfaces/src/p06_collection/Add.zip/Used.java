package p06_collection;

public interface Used extends Remove{
    int used();
}
