package p06_collection;

public interface Add {
    int add(String ele);
}
