package p06_collection;

public interface Remove extends Add{
    String remove();
}
