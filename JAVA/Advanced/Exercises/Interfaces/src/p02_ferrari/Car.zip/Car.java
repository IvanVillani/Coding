package p02_ferrari;

public interface Car {
    String useBrakes();
    String pushTheGas();
}
