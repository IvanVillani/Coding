package p07_mood3;

public interface Able {
    void hash(String username);
}
