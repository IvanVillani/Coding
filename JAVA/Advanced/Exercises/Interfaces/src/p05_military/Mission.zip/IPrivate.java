package p05_military;

public interface IPrivate {
}
