package p01_person;

public interface Person {
    String getName();
    int getAge();
}
