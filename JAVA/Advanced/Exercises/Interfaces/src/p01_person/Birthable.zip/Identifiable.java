package p01_person;

public interface Identifiable {
    String getId();
}
