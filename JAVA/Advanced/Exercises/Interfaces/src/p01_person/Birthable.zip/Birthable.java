package p01_person;

public interface Birthable {
    String getBirthdate();
}
