package p03_telephony;

public interface Browseable {
    String browse(String url);
}
