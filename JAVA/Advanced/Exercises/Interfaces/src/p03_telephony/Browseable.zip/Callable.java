package p03_telephony;

public interface Callable {
    String call(String number);
}
