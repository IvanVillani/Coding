package p05_military;

public interface ISpecialisedSoldier {
    void setCorps(String corps);
}
