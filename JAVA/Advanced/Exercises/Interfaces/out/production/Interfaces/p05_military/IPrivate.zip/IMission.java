package p05_military;

public interface IMission {
    void setState(String state);
}
