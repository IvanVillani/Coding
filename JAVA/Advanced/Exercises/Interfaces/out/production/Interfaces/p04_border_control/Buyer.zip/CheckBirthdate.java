package p04_border_control;

public interface CheckBirthdate {
    void setBirthdate(String birthdate);
}
