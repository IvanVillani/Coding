package p02_king_gambit.interfaces;

public interface Attackable {
    void takeAttack();
}
