package p01_event_manipulation;


public class NameChange{
    private String nameChanged;

    public NameChange(String nameChanged) {
        this.nameChanged = nameChanged;
    }

    public String getNameChanged() {
        return nameChanged;
    }
}
