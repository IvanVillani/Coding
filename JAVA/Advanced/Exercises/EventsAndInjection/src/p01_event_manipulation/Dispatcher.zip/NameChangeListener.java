package p01_event_manipulation;

public interface NameChangeListener {
    void handleChangedName(NameChange event);
}
