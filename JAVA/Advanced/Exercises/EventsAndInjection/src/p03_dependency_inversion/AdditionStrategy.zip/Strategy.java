package p03_dependency_inversion;

public interface Strategy {
    int calculate(int firstOperand, int secondOperand);
}
