package p02_wild_farm;

import p02_wild_farm.Food;

public class Meat extends Food {
    public Meat(int guantity) {
        super(guantity);
    }
}
