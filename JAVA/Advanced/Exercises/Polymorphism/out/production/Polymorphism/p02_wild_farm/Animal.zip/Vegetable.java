package p02_wild_farm;

import p02_wild_farm.Food;

public class Vegetable extends Food {
    public Vegetable(int guantity) {
        super(guantity);
    }
}
