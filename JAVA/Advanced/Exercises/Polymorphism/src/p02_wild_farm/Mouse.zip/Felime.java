package p02_wild_farm;



public abstract class Felime extends Mammal {
    public Felime(String animalName, String animalType, double animalWeight, String livingRegion) {
        super(animalName, animalType, animalWeight, livingRegion);
    }

}
