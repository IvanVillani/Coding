package root.io;

public class ConsoleWriter {
    public void write(String line) {
        System.out.println(line);
    }
}
