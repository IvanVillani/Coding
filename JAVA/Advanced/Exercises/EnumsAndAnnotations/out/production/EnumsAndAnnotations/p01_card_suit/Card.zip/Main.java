package p01_card_suit;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import static java.lang.System.in;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));

        CardRanks[] cardRanks = CardRanks.values();
        CardSuits[] cardSuits = CardSuits.values();

        if ("Card Deck".equals(reader.readLine())) {
            for (CardSuits cardSuit : cardSuits) {
                for (CardRanks cardRank : cardRanks) {
                    System.out.printf("%s of %s%n", cardRank.name(), cardSuit.name());
                }
            }
        }

    }
}
