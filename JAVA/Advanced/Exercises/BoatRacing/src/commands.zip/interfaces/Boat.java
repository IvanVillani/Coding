package interfaces;

public interface Boat {
    boolean isMotorBoat();

    double calculateRaceSpeed(IRace IRace);
}
