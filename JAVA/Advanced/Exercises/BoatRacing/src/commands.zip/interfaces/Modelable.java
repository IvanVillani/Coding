package interfaces;

public interface Modelable {
    String getModel();
}
