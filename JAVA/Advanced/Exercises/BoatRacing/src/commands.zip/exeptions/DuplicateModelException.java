package exeptions;

public class DuplicateModelException extends Exception {
    public DuplicateModelException(String message) {
        super(message);
    }

}
